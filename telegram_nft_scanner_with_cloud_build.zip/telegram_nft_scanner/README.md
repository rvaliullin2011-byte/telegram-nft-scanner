# Telegram NFT Scanner

Starter project: Android Kotlin/Jetpack Compose client + Python FastAPI/Telethon backend.

**Coverage limitation:** Telegram does not provide a global API to enumerate every user or every NFT owner. The backend polls the gift catalogue and can inspect saved gifts only for explicitly configured peers that the authenticated account is allowed to access. It does not bypass privacy controls.

## Backend
1. Install Python 3.11+.
2. Copy `backend/.env.example` to `backend/.env`.
3. Create Telegram API credentials at https://my.telegram.org/apps.
4. Generate a Telethon session string on a trusted machine with `python make_session.py`.
5. Install and run:
   `pip install -r requirements.txt`
   `uvicorn app:app --host 0.0.0.0 --port 8000`

Keep API_HASH and SESSION_STRING secret. Set WATCH_USERNAMES to a comma-separated list of usernames whose accessible saved gifts you want to monitor.

## Android
Open `android/` in Android Studio, sync Gradle, then Build > Build APK(s).
The APK itself is not included: this execution environment has Java but no Android SDK or Gradle installation, so an APK cannot be compiled here. Set API_BASE_URL in app/build.gradle.kts to your backend URL before building. Use HTTPS in production.


## Current delivery status
This is an initial source-code baseline, not a finished or security-audited production release. No Telegram account has been connected and no APK has been built or tested. A real deployment still needs the owner's Telegram API credentials/session, a server host with persistent uptime, HTTPS, API authentication, and Android SDK/Gradle build environment.

## Cloud APK build workflow
A GitHub Actions workflow is included at `.github/workflows/build-android.yml`. After the project is pushed to a GitHub repository, run the workflow from the Actions tab (or push changes to `android/`). The generated debug APK is published as the artifact `telegram-nft-scanner-debug-apk`.
