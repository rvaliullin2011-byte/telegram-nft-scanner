package com.example.nftscanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

data class Status(val running: Boolean = false, val last_scan: Long? = null, val scan_error: String? = null, val interval_seconds: Int = 300)
data class Discovery(val id: Int, val kind: String, val title: String, val source: String, val discovered_at: Long)
interface ScannerApi {
    @GET("api/status") suspend fun status(): Status
    @GET("api/discoveries") suspend fun discoveries(@Query("limit") limit: Int = 100): List<Discovery>
    @POST("api/scan") suspend fun scan(): Map<String, Any>
}
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val api = Retrofit.Builder().baseUrl(BuildConfig.API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build().create(ScannerApi::class.java)
        setContent { MaterialTheme { ScannerHome(api) } }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerHome(api: ScannerApi) {
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf(Status()) }
    var entries by remember { mutableStateOf(emptyList<Discovery>()) }
    var message by remember { mutableStateOf("Connecting…") }
    var busy by remember { mutableStateOf(false) }
    suspend fun refresh() {
        busy = true
        try {
            state = withContext(Dispatchers.IO) { api.status() }
            entries = withContext(Dispatchers.IO) { api.discoveries() }
            message = if (state.running) "Backend connected" else "Backend offline / not authorized"
        } catch (_: Exception) {
            message = "Cannot reach backend. Configure API_BASE_URL."
        }
        busy = false
    }
    LaunchedEffect(Unit) { refresh() }
    Scaffold(topBar = { TopAppBar(title = { Text("Telegram NFT Scanner") }) }) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Scanner status", style = MaterialTheme.typography.titleLarge)
                        Text(if (state.running) "● RUNNING" else "○ OFFLINE")
                        Text(message)
                        Text("Continuous scan · every ${state.interval_seconds} seconds")
                        state.scan_error?.let { Text("Error: $it") }
                        Button(enabled = state.running && !busy, onClick = { scope.launch {
                            busy = true
                            try { withContext(Dispatchers.IO) { api.scan() } } catch (e: Exception) { message = e.message ?: "Scan failed" }
                            refresh()
                        } }) { Text(if (busy) "Working…" else "Scan now") }
                        OutlinedButton(onClick = { scope.launch { refresh() } }, enabled = !busy) { Text("Refresh") }
                    }
                }
            }
            item { Text("Recent discoveries", style = MaterialTheme.typography.titleLarge) }
            if (entries.isEmpty()) item { Text("No discoveries yet. Start the backend to populate this list.") }
            items(entries) { entry ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(entry.title, style = MaterialTheme.typography.titleMedium)
                        Text("${entry.kind} · ${entry.source}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("Coverage is limited to Telegram data accessible to the authenticated account. Private ownership and a global user list are not available.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
