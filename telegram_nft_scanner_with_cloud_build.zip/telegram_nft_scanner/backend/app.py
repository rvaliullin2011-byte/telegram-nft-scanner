import os, json, time, asyncio, sqlite3, logging
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from telethon import TelegramClient, functions
from telethon.sessions import StringSession

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("nft-scanner")
DB = os.getenv("DATABASE_PATH", "./scanner.db")
API_ID, API_HASH, SESSION = os.getenv("TG_API_ID"), os.getenv("TG_API_HASH"), os.getenv("TG_SESSION_STRING")
INTERVAL = max(60, int(os.getenv("SCAN_INTERVAL_SECONDS", "300")))
WATCH = [x.strip().lstrip("@") for x in os.getenv("WATCH_USERNAMES", "").split(",") if x.strip()]
client = None
last_scan = None
scan_error = None

def connect_db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def save(kind, key, title, details, source):
    with connect_db() as c:
        c.execute("INSERT OR IGNORE INTO discoveries(kind,key,title,details,source,discovered_at) VALUES(?,?,?,?,?,?)",
                  (kind, key, title, json.dumps(details, ensure_ascii=False), source, int(time.time())))

def fields(obj):
    result = {}
    for name in ("id", "title", "slug", "availability_total", "availability_remains", "stars", "limited", "sold_out"):
        value = getattr(obj, name, None)
        if value is not None:
            result[name] = str(value) if not isinstance(value, (str, int, float, bool)) else value
    return result

async def scan_once():
    global last_scan, scan_error
    if client is None:
        raise RuntimeError("Telegram session is not configured")
    try:
        catalogue = await client(functions.payments.GetStarGiftsRequest(hash=0))
        gifts = getattr(catalogue, "gifts", []) or []
        for gift in gifts:
            data = fields(gift)
            gid = str(data.get("id", "unknown"))
            save("gift_catalog", "gift:" + gid, data.get("title") or ("Gift " + gid), data, "Telegram gift catalogue")
        for username in WATCH:
            try:
                peer = await client.get_input_entity(username)
                saved = await client(functions.payments.GetSavedStarGiftsRequest(peer=peer, offset="", limit=100, hash=0))
                for item in getattr(saved, "gifts", []) or []:
                    gift = getattr(item, "gift", None)
                    data = fields(gift) if gift else {}
                    data["watched_username"] = username
                    owner = getattr(item, "from_id", None)
                    data["owner_peer"] = str(owner) if owner else None
                    key = "saved:%s:%s:%s" % (username, getattr(gift, "id", "unknown"), getattr(item, "date", ""))
                    save("saved_gift", key, "Gift observed for @" + username, data, "Accessible saved gifts")
            except Exception as exc:
                log.warning("Cannot inspect @%s: %s", username, exc)
        last_scan, scan_error = int(time.time()), None
    except Exception as exc:
        scan_error = str(exc)
        raise

async def scan_loop():
    while True:
        try:
            await scan_once()
        except Exception:
            log.exception("Scheduled scan failed")
        await asyncio.sleep(INTERVAL)

@asynccontextmanager
async def lifespan(app):
    global client
    with connect_db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS discoveries (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, key TEXT UNIQUE, title TEXT, details TEXT, source TEXT, discovered_at INTEGER)")
    task = None
    if API_ID and API_HASH and SESSION and SESSION != "replace_me":
        client = TelegramClient(StringSession(SESSION), int(API_ID), API_HASH)
        await client.connect()
        if await client.is_user_authorized():
            task = asyncio.create_task(scan_loop())
        else:
            await client.disconnect()
            client = None
    yield
    if task:
        task.cancel()
    if client and client.is_connected():
        await client.disconnect()

app = FastAPI(title="Telegram NFT Scanner API", lifespan=lifespan)

@app.get("/api/status")
def status():
    return {"running": client is not None, "last_scan": last_scan, "scan_error": scan_error,
            "interval_seconds": INTERVAL, "watched_usernames": WATCH}

@app.post("/api/scan")
async def manual_scan():
    if client is None:
        raise HTTPException(503, "Backend is not configured or Telegram session is unauthorized")
    try:
        await scan_once()
        return {"ok": True, "last_scan": last_scan}
    except Exception as exc:
        raise HTTPException(502, str(exc))

@app.get("/api/discoveries")
def discoveries(limit: int = 100):
    limit = max(1, min(limit, 500))
    with connect_db() as c:
        rows = c.execute("SELECT * FROM discoveries ORDER BY discovered_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(row) | {"details": json.loads(row["details"])} for row in rows]

@app.get("/health")
def health():
    return {"ok": True}
