import asyncio, os
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

load_dotenv()
async def main():
    async with TelegramClient(StringSession(), int(os.environ["TG_API_ID"]), os.environ["TG_API_HASH"]) as client:
        print("Keep this session string private:")
        print(StringSession.save(client.session))
asyncio.run(main())
